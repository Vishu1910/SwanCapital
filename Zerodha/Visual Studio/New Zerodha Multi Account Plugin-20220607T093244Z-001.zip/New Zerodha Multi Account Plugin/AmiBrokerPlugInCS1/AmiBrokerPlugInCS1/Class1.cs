﻿using System;
using AmiBroker;
using AmiBroker.PlugIn;
using System.Security.Cryptography;
using System.Text;
using System.Net;
using System.IO;
using System.Net.Http;
using System.Collections.Generic;
//using AmiBroker.Utils;

namespace AmiBrokerPlugInCS1
{
    public class Class1 : IndicatorBase
    {


        // instances of Kite and Ticker
        static Ticker ticker;
        static ZerodhaBroker kite;

        // Initialize key and secret of your app
        static string MyAPIKey = "ijqjp8eqygba1rw2";
        static string MySecret = "ihd0u03xd4i7caqs78i174o6di7bqr9e";
        static string MyUserId = "YS0121";
        static string MyPublicToken = "abcdefghijklmnopqrstuvwxyz";
        static string MyAccessToken = "abcdefghijklmnopqrstuvwxyz";

        [ABMethod]
        public ATArray AmiBrokerPlugInCS1Func2(ATArray array, float period)
        {
            ATArray result = AFAvg.Ma(array, period);
            return result;
        }

        [ABMethod]
        public ATArray AmiBrokerPlugInCS1Func3(ATArray array, float period)
        {
            ATArray result = AFAvg.Ma(array, period);
            return result;
        }

        private static void OnTokenExpire()
        {

        }

        public static string SHA256(string Data)
        {
            SHA256Managed sha256 = new SHA256Managed();
            StringBuilder hexhash = new StringBuilder();
            byte[] hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(Data), 0, Encoding.UTF8.GetByteCount(Data));
            foreach (byte b in hash)
            {
                hexhash.Append(b.ToString("x2"));
            }
            return hexhash.ToString();
        }

        [ABMethod]
        public static string Login(string requesttoken)
        {

            var createsha = MyAPIKey + requesttoken + MySecret;
            var checksum = SHA256(createsha);

            try
            {
                var client = new HttpClient();

                var pairs = new List<KeyValuePair<string, string>>
    {
        new KeyValuePair<string, string>("api_key", MyAPIKey),
        new KeyValuePair<string, string>("request_token", requesttoken),
        new KeyValuePair<string, string>("checksum", checksum)
    };

                var content = new FormUrlEncodedContent(pairs);

                var responsess = client.PostAsync("https://api.kite.trade/session/token", content).Result;

                if (responsess.IsSuccessStatusCode)
                {
                    var ss = responsess.Content.ReadAsStringAsync().Result;
                    return ss;
                }
                else
                {
                    var ss = responsess.Content.ReadAsStringAsync().Result;
                    return ss;
                }

                

            }
            catch (WebException ex)
            {
                return ex.Message;
                //using (WebResponse response = ex.Response)
                //{
                //    HttpWebResponse httpResponse = (HttpWebResponse)response;
                //    Console.WriteLine("Error code: {0}", httpResponse.StatusCode);
                //    using (Stream data = response.GetResponseStream())
                //    using (var reader = new StreamReader(data))
                //    {
                //        string text = reader.ReadToEnd();
                //        return text;

                //    }
                //}
            }

        }


        [ABMethod]
        public static string GetOrder(string accesstoken)
        {

            try {

                HttpClient client = new HttpClient();
                client.DefaultRequestHeaders.Add("Authorization", "token " + MyAPIKey + ":" + accesstoken);
                HttpResponseMessage responsess = client.GetAsync("https://api.kite.trade/orders").Result;  // Blocking call!  
                if (responsess.IsSuccessStatusCode)
                {
                    var ss = responsess.Content.ReadAsStringAsync().Result;
                    return ss;
                }
                else
                {
                    var ss = responsess.Content.ReadAsStringAsync().Result;
                    return ss;
                }
            }
            catch (WebException ex)
            {
                return ex.Message;
               
            }

        }


        [ABMethod]
        public static string GetOrdersbyId(string OrderId,string accesstoken)
        {

            try
            {

                HttpClient client = new HttpClient();
                client.DefaultRequestHeaders.Add("Authorization", "token " + MyAPIKey + ":" + accesstoken);
                HttpResponseMessage responsess = client.GetAsync("https://api.kite.trade/orders/"+OrderId).Result;  // Blocking call!  
                if (responsess.IsSuccessStatusCode)
                {
                    var ss = responsess.Content.ReadAsStringAsync().Result;
                    return ss;
                }
                else
                {
                    var ss = responsess.Content.ReadAsStringAsync().Result;
                    return ss;
                }
            }
            catch (WebException ex)
            {
                return ex.Message;
                
            }

        }


        [ABMethod]
        public static string Placezerodhaorder(string accesstoken, string Exchange,
            string TradingSymbol,
            string TransactionType,
            string Quantity,
            string Price = null,
            string Product = null,
            string OrderType = null,
            string Validity = null,
            string DisclosedQuantity = null,
            string TriggerPrice = null,
            string SquareOffValue = null,
            string StoplossValue = null,
            string TrailingStoploss = null,
            string Variety = Constants.VARIETY_REGULAR,
            string Tag = "")
        {


            try
            {
                var client = new HttpClient();
                var pairs = new List<KeyValuePair<string, string>>
    {
        new KeyValuePair<string, string>("exchange", Exchange),
        new KeyValuePair<string, string>("tradingsymbol", TradingSymbol),
        new KeyValuePair<string, string>("transaction_type", TransactionType),
        new KeyValuePair<string, string>("quantity", Quantity.ToString()),
        new KeyValuePair<string, string>("price", Price.ToString()),
        new KeyValuePair<string, string>("product", Product),
        new KeyValuePair<string, string>("order_type", OrderType),
        new KeyValuePair<string, string>("validity", Validity),
        new KeyValuePair<string, string>("disclosed_quantity", DisclosedQuantity.ToString()),
        new KeyValuePair<string, string>("trigger_price", TriggerPrice.ToString()),
        new KeyValuePair<string, string>("squareoff", SquareOffValue.ToString()),
        new KeyValuePair<string, string>("stoploss", StoplossValue.ToString()),
        new KeyValuePair<string, string>("trailing_stoploss", TrailingStoploss.ToString()),
        new KeyValuePair<string, string>("variety", Variety),
        new KeyValuePair<string, string>("tag", Tag)
    };


                var content = new FormUrlEncodedContent(pairs);
                client.DefaultRequestHeaders.Add("Authorization", "token " + MyAPIKey + ":" + accesstoken);
                var responsess = client.PostAsync("https://api.kite.trade/orders/"+Variety, content).Result;

                if (responsess.IsSuccessStatusCode)
                {
                    var ss = responsess.Content.ReadAsStringAsync().Result;
                    return ss;
                }
                else
                {
                    var ss = responsess.Content.ReadAsStringAsync().Result;
                    return ss;
                }

            }
            catch (WebException ex)
            {
                return ex.Message;
            }

        }


        [ABMethod]
        public static string CancelZerodhaorder(string accesstoken,string OrderId,string  Variety,string ParentOrderId)
        {

            try
            {

                HttpClient client = new HttpClient();
                var pairs = new List<KeyValuePair<string, string>>
    {
        new KeyValuePair<string, string>("order_id", OrderId),
        new KeyValuePair<string, string>("parent_order_id", ParentOrderId),
        new KeyValuePair<string, string>("variety", Variety)
       
    };
                client.DefaultRequestHeaders.Add("Authorization", "token " + MyAPIKey + ":" + accesstoken);
                HttpResponseMessage responsess = client.DeleteAsync("https://api.kite.trade/orders/" + Variety+"/"+OrderId).Result;  // Blocking call!  
                if (responsess.IsSuccessStatusCode)
                {
                    var ss = responsess.Content.ReadAsStringAsync().Result;
                    return ss;
                }
                else
                {
                    var ss = responsess.Content.ReadAsStringAsync().Result;
                    return ss;
                }
            }
            catch (WebException ex)
            {
                return ex.Message;

            }

        }

        [ABMethod]
        public static string Modifyzerodhaorder(string accesstoken, string OrderId,
            string ParentOrderId = null,
            string Exchange = null,
            string TradingSymbol = null,
            string TransactionType = null,
            string Quantity = null,
            string Price = null,
            string Product = null,
            string OrderType = null,
            string Validity = Constants.VALIDITY_DAY,
            string DisclosedQuantity = null,
            string TriggerPrice = null,
            string Variety = Constants.VARIETY_REGULAR
)
        {


            try
            {
                string VarietyString = Variety;
                string ProductString = Product;
                var client = new HttpClient();
                client.DefaultRequestHeaders.Add("Authorization", "token " + MyAPIKey + ":" + accesstoken);

                if ((ProductString == "bo" || ProductString == "co") && VarietyString != ProductString)
                {
                    return "Invalid variety. It should be: " + ProductString;
                }
                if (VarietyString == "bo" && ProductString == "bo")
                {
                    var pairs = new List<KeyValuePair<string, string>>()
    {
        new KeyValuePair<string, string>("order_id", OrderId),
        new KeyValuePair<string, string>("parent_order_id", ParentOrderId),
        new KeyValuePair<string, string>("trigger_price", TriggerPrice.ToString()),
        new KeyValuePair<string, string>("variety", Variety),
         new KeyValuePair<string, string>("quantity", Quantity),
        new KeyValuePair<string, string>("price", Price.ToString()),
        new KeyValuePair<string, string>("disclosed_quantity", DisclosedQuantity.ToString())
    };
                    var content = new FormUrlEncodedContent(pairs);

                    var responsess = client.PutAsync("https://api.kite.trade/orders/" + Variety + "/" + OrderId, content).Result;

                    if (responsess.IsSuccessStatusCode)
                    {
                        var ss = responsess.Content.ReadAsStringAsync().Result;
                        return ss;
                    }
                    else
                    {
                        var ss = responsess.Content.ReadAsStringAsync().Result;
                        return ss;
                    }
                }
                else if (VarietyString != "co" && ProductString != "co")
                {
                    var pairs = new List<KeyValuePair<string, string>>()
    {
        new KeyValuePair<string, string>("order_id", OrderId),
        new KeyValuePair<string, string>("parent_order_id", ParentOrderId),
        new KeyValuePair<string, string>("trigger_price", TriggerPrice.ToString()),
        new KeyValuePair<string, string>("variety", Variety),
         new KeyValuePair<string, string>("exchange", Exchange),
        new KeyValuePair<string, string>("tradingsymbol", TradingSymbol),
        new KeyValuePair<string, string>("transaction_type", TransactionType),
        new KeyValuePair<string, string>("quantity", Quantity.ToString()),
        new KeyValuePair<string, string>("price", Price.ToString()),
        new KeyValuePair<string, string>("product", Product),
        new KeyValuePair<string, string>("order_type", OrderType),
        new KeyValuePair<string, string>("validity", Validity),
        new KeyValuePair<string, string>("disclosed_quantity", DisclosedQuantity.ToString()),
    };
                    var content = new FormUrlEncodedContent(pairs);

                    var responsess = client.PutAsync("https://api.kite.trade/orders/" + Variety + "/" + OrderId, content).Result;

                    if (responsess.IsSuccessStatusCode)
                    {
                        var ss = responsess.Content.ReadAsStringAsync().Result;
                        return ss;
                    }
                    else
                    {
                        var ss = responsess.Content.ReadAsStringAsync().Result;
                        return ss;
                    }
                }
                return "Error";
            }
            catch (WebException ex)
            {
                return ex.Message;
            }

        }

        [ABMethod]
        public static string getzerodhaholdings(string accesstoken)
        {

            try
            {

                HttpClient client = new HttpClient();
                client.DefaultRequestHeaders.Add("Authorization", "token " + MyAPIKey + ":" + accesstoken);
                HttpResponseMessage responsess = client.GetAsync("https://api.kite.trade/portfolio/holdings").Result;  // Blocking call!  
                if (responsess.IsSuccessStatusCode)
                {
                    var ss = responsess.Content.ReadAsStringAsync().Result;
                    return ss;
                }
                else
                {
                    var ss = responsess.Content.ReadAsStringAsync().Result;
                    return ss;
                }
            }
            catch (WebException ex)
            {
                return ex.Message;

            }

        }

        [ABMethod]
        public static string getzerodhapositions(string accesstoken)
        {

            try
            {

                HttpClient client = new HttpClient();
                client.DefaultRequestHeaders.Add("Authorization", "token " + MyAPIKey + ":" + accesstoken);
                HttpResponseMessage responsess = client.GetAsync("https://api.kite.trade/portfolio/positions").Result;  // Blocking call!  
                if (responsess.IsSuccessStatusCode)
                {
                    var ss = responsess.Content.ReadAsStringAsync().Result;
                    return ss;
                }
                else
                {
                    var ss = responsess.Content.ReadAsStringAsync().Result;
                    return ss;
                }
            }
            catch (WebException ex)
            {
                return ex.Message;

            }

        }

    }
}
