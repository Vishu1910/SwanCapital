﻿using System;
using AmiBroker;
using AmiBroker.PlugIn;
using AmiBroker.Utils;

namespace AmiBrokerPlugInCS2
{
    public class Class1 : IndicatorBase
    {
        [ABMethod]
        public ATArray AmiBrokerPlugInCS2Func1(ATArray array, float period)
        {
            ATArray result = AFAvg.Ma(array, period);
            return result;
        }
    }
}
